package es.magicwater.repositorios;

import es.magicwater.jpa.Tarea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TareaRepositorio extends JpaRepository<Tarea, Integer> {
    @Query("SELECT MAX(t.idtarea)+1 FROM Tarea t")
    Integer newIdTarea();

    // Contar tareas por estado
    long countByEstado(String estado);


    @Query("SELECT u.nombre, COUNT(t) FROM Tarea t JOIN t.usuario u WHERE t.estado IN ('Pendiente', 'En Curso') GROUP BY u.nombre")
    List<Object[]> countTareasPendientesOEnCursoPorUsuario();

    @Query("SELECT u.nombre, COUNT(t) FROM Tarea t JOIN t.usuario u WHERE t.estado = 'Terminada' GROUP BY u.nombre")
    List<Object[]> countTareasTerminadasPorUsuario();





}